FIJI HUSTLE — zero-cost MVP
1. Open index.html in Chrome to test it.
2. To make it installable as a PWA for other people, host these files on a HTTPS static host such as GitHub Pages or Cloudflare Pages.
3. The current version is a front-end demo: listings are stored on the device. A public version needs a backend/database.
4. Monetization plan: verified sponsored listings + ads after there is real traffic. Never charge users to access basic listings.
5. Do not publish fake jobs or guaranteed earnings. Verify businesses and opportunities before featuring them.
